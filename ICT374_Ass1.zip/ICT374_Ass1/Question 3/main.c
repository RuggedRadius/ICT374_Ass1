/* File Name:       main.c
 * Author:          Ben Royans
 * Date Modified:   04/09/2023
 * Assignment:      1
 * Question:        3
 */